
This directly contains sample data hat can be used in your Project #2. 
In particular, it contains information about artists, events (concerts), 
venues, genres, and subgenres. The data has 2000 events, 1454 
performers, 409 venues, 106 genres and 248 sub-genres and is 
available in both JSON (using GSON) and CSV (using SuperCSV) formats.

Note that you are NOT required to use this data, but using it might make
for a more interesting data set. You may use, chop, or modify this data
as you want, or not use it at all. You probably have to adapt the data to
your schema — you do not have to modify your schema to be the same
as this data. 